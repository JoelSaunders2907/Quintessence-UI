import React, { useState } from 'react';
import { ChevronDown, ChevronRight } from 'lucide-react';
import { ProcessStatus, ProcessNode, ProcessItemProps } from '../types/process';
import { StatusBadge } from './StatusBadge';

export function ProcessItem({ name, status, children, level }: ProcessItemProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const hasChildren = Object.keys(children).length > 0;

  return (
    <div className="w-full">
      <div 
        className={`
          flex items-center gap-2 p-2 hover:bg-gray-50 cursor-pointer
          ${level === 0 ? 'bg-white shadow-sm rounded-lg mb-2' : 'pl-6'}
        `}
        onClick={() => setIsExpanded(!isExpanded)}
      >
        {hasChildren && (
          <span className="text-gray-500">
            {isExpanded ? (
              <ChevronDown className="w-4 h-4" />
            ) : (
              <ChevronRight className="w-4 h-4" />
            )}
          </span>
        )}
        <span className="flex-1 font-medium">{name}</span>
        <StatusBadge status={status} />
      </div>
      
      {isExpanded && hasChildren && (
        <div className="ml-4 border-l border-gray-200">
          {Object.entries(children).map(([childName, [childStatus, childChildren]]) => (
            <ProcessItem
              key={childName}
              name={childName}
              status={childStatus}
              children={childChildren}
              level={level + 1}
            />
          ))}
        </div>
      )}
    </div>
  );
}