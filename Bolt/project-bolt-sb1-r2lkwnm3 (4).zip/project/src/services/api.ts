import { ProcessNode } from '../types/process';

const API_URL = 'http://127.0.0.1:5000/hierarchy';

export async function fetchProcessData(): Promise<ProcessNode> {
  try {
    console.log('Fetching data from:', API_URL);
    
    const response = await fetch(API_URL, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Cache-Control': 'no-cache',
      },
      credentials: 'omit',
    });
    
    if (!response.ok) {
      throw new Error(`Server responded with status: ${response.status}`);
    }
    
    // Get the raw text first
    const rawText = await response.text();
    console.log('Raw API Response:', rawText);
    
    try {
      // Try parsing the raw text as JSON
      const data = JSON.parse(rawText);
      console.log('Parsed Data:', data);
      
      // Validate that we received an object
      if (!data || typeof data !== 'object') {
        throw new Error('Invalid data format received from server');
      }
      
      return data;
    } catch (parseError) {
      console.error('JSON Parse Error:', parseError);
      throw new Error('Failed to parse server response as JSON');
    }
    
  } catch (error) {
    if (error instanceof TypeError && error.message.includes('Failed to fetch')) {
      throw new Error('Unable to connect to the server. Please ensure the API is running at http://127.0.0.1:5000');
    }
    console.error('Error fetching data:', error);
    throw error;
  }
}