import React, { useState, useEffect } from 'react';
import { ProcessViewer } from './components/ProcessViewer';
import { fetchProcessData } from './services/api';
import { ProcessNode } from './types/process';

function App() {
  const [processData, setProcessData] = useState<ProcessNode>({});
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = async () => {
    setIsLoading(true);
    setError(null);
    try {
      console.log('Fetching new data...');
      const data = await fetchProcessData();
      console.log('Setting process data:', data);
      setProcessData(data);
      setLastUpdated(new Date());
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';
      console.error('Error in fetchData:', errorMessage);
      setError(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    console.log('Initial data fetch...');
    fetchData();
  }, []);

  console.log('Current state:', { 
    hasData: Object.keys(processData).length > 0,
    isLoading,
    error,
    lastUpdated: lastUpdated.toISOString()
  });

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h1 className="text-2xl font-bold text-gray-800 mb-6">Process Monitor</h1>
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
              <p className="font-medium">Connection Error</p>
              <p className="text-sm mt-1">{error}</p>
            </div>
          )}
          <ProcessViewer 
            data={processData}
            lastUpdated={lastUpdated}
            onRefresh={fetchData}
            isLoading={isLoading}
          />
        </div>
      </div>
    </div>
  );
}