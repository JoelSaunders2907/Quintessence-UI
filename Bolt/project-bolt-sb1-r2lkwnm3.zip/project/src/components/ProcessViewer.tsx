import React from 'react';
import { ProcessNode } from '../types/process';
import { ProcessItem } from './ProcessItem';

interface ProcessViewerProps {
  data: ProcessNode;
}

export function ProcessViewer({ data }: ProcessViewerProps) {
  return (
    <div className="w-full max-w-3xl mx-auto space-y-4">
      {Object.entries(data).map(([name, [status, children]]) => (
        <ProcessItem
          key={name}
          name={name}
          status={status}
          children={children}
          level={0}
        />
      ))}
    </div>
  );
}