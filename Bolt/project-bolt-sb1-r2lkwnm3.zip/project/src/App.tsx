import React from 'react';
import { ProcessViewer } from './components/ProcessViewer';

const processData = {
  "Prepare Reporting - Alchemy and CashMi": [
    "RUNNING",
    {
      "PnL": [
        "CACHING",
        {
          "All Alchemy Source Files": [
            "COMPLETED",
            {
              "TRADE_CRN": ["COMPLETED", {}],
              "TRADE_ELNA": ["COMPLETED", {}],
              "TRADE_RSAB": ["COMPLETED", {}]
            }
          ]
        }
      ],
      "Lookup": [
        "WAITING",
        {
          "All Alchemy Source Files": [
            "COMPLETED",
            {
              "TRADE_CRN": ["COMPLETED", {}],
              "TRADE_ELNA": ["COMPLETED", {}],
              "TRADE_RSAB": ["COMPLETED", {}]
            }
          ]
        }
      ],
      "TB": [
        "WAITING",
        {
          "All Alchemy Source Files": [
            "COMPLETED",
            {
              "TRADE_CRN": ["COMPLETED", {}],
              "TRADE_ELNA": ["COMPLETED", {}],
              "TRADE_RSAB": ["COMPLETED", {}]
            }
          ]
        }
      ]
    }
  ],
  "Prepare Reporting - Hiport": [
    "WAITING",
    {
      "All Hiport Source Files": [
        "IMPORTING",
        {
          "H2_HOLDING": ["IMPORTING", {}],
          "H3_HOLDING": ["RECONCILING", {}]
        }
      ]
    }
  ]
};

function App() {
  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold text-gray-800 mb-6">Process Monitor</h1>
        <ProcessViewer data={processData} />
      </div>
    </div>
  );
}

export default App;