export type ProcessStatus = 'RUNNING' | 'WAITING' | 'COMPLETED' | 'CACHING' | 'IMPORTING' | 'RECONCILING';

export interface ProcessNode {
  [key: string]: [ProcessStatus, ProcessNode];
}

export interface ProcessItemProps {
  name: string;
  status: ProcessStatus;
  children: ProcessNode;
  level: number;
}