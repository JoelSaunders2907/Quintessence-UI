import { ProcessNode } from '../types/process';

const API_URL = 'https://api.example.com/process-state'; // Replace with your actual API endpoint

export async function fetchProcessData(): Promise<ProcessNode> {
  try {
    const response = await fetch(API_URL);
    if (!response.ok) {
      throw new Error('Failed to fetch process data');
    }
    return await response.json();
  } catch (error) {
    console.error('Error fetching process data:', error);
    throw error;
  }
}