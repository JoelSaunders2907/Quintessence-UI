import { useState, useCallback } from 'react';
import { ProcessNode } from '../types/process';
import { fetchProcessData } from '../services/api';

export function useProcessData() {
  const [processData, setProcessData] = useState<ProcessNode>({});
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [refreshType, setRefreshType] = useState<'button' | 'page' | null>(null);

  const fetchData = useCallback(async (type: 'button' | 'page') => {
    setIsLoading(true);
    setError(null);
    setRefreshType(type);
    
    console.log(`[${type.toUpperCase()} REFRESH] Starting data fetch...`);
    
    try {
      const data = await fetchProcessData();
      console.log(`[${type.toUpperCase()} REFRESH] Received data:`, {
        dataType: typeof data,
        isArray: Array.isArray(data),
        keys: Object.keys(data),
        rawData: data
      });
      
      setProcessData(data);
      setLastUpdated(new Date());
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';
      console.error(`[${type.toUpperCase()} REFRESH] Error:`, errorMessage);
      setError(errorMessage);
    } finally {
      setIsLoading(false);
      setRefreshType(null);
    }
  }, []);

  return {
    processData,
    lastUpdated,
    isLoading,
    error,
    refreshType,
    fetchData
  };
}