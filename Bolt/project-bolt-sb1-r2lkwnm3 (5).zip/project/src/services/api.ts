import { ProcessNode } from '../types/process';

const API_URL = 'http://127.0.0.1:5000/hierarchy';

export async function fetchProcessData(): Promise<ProcessNode> {
  const requestId = Math.random().toString(36).substring(7);
  console.log(`[API ${requestId}] Fetching data from:`, API_URL);
  
  try {
    const response = await fetch(API_URL, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0',
      },
      credentials: 'omit',
    });
    
    if (!response.ok) {
      throw new Error(`Server responded with status: ${response.status}`);
    }
    
    // Get the raw text first
    const rawText = await response.text();
    console.log(`[API ${requestId}] Raw response:`, rawText);
    
    try {
      // Try parsing the raw text as JSON
      const data = JSON.parse(rawText);
      console.log(`[API ${requestId}] Parsed data:`, data);
      
      // Validate the response structure
      if (!data || typeof data !== 'object') {
        throw new Error('Invalid data format: Expected an object');
      }
      
      // Validate the expected structure
      Object.entries(data).forEach(([key, value]) => {
        if (!Array.isArray(value) || value.length !== 2) {
          throw new Error(`Invalid data structure for key "${key}": Expected [status, children] array`);
        }
      });
      
      return data;
    } catch (parseError) {
      console.error(`[API ${requestId}] Parse error:`, parseError);
      throw new Error(`Failed to parse response: ${parseError.message}`);
    }
  } catch (error) {
    if (error instanceof TypeError && error.message.includes('Failed to fetch')) {
      throw new Error('Unable to connect to the server. Please ensure the API is running at http://127.0.0.1:5000');
    }
    throw error;
  }
}