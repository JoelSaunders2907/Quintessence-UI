import React, { useEffect } from 'react';
import { ProcessViewer } from './components/ProcessViewer';
import { useProcessData } from './hooks/useProcessData';

export function App() {
  const { 
    processData, 
    lastUpdated, 
    isLoading, 
    error, 
    fetchData 
  } = useProcessData();

  useEffect(() => {
    console.log('[PAGE LOAD] Initial data fetch...');
    fetchData('page');
  }, [fetchData]);

  const handleRefresh = () => {
    console.log('[BUTTON CLICK] Manual refresh triggered');
    fetchData('button');
  };

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h1 className="text-2xl font-bold text-gray-800 mb-6">Process Monitor</h1>
          {error && (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
              <p className="font-medium">Connection Error</p>
              <p className="text-sm mt-1">{error}</p>
            </div>
          )}
          <ProcessViewer 
            data={processData}
            lastUpdated={lastUpdated}
            onRefresh={handleRefresh}
            isLoading={isLoading}
          />
        </div>
      </div>
    </div>
  );
}